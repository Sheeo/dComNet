#!/bin/sh
while read x y; do
	sh imulwc.sh $x $y
done
