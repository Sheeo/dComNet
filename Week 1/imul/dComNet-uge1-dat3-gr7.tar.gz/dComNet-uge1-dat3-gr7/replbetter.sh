#!/bin/sh
while read x y; do
	sh imulbetterwc.sh $x $y
done
