#!/bin/sh
sh imul.j.sh $1 $2 | wc -l
